/************************************************************************
** IBM Confidential
**
** OCO Source Materials
**
** IBM SPSS Products: Statistics Common
**
** (C) Copyright IBM Corp. 1989, 2021
**
** The source code for this program is not published or otherwise divested of its trade secrets, 
** irrespective of what has been deposited with the U.S. Copyright Office.
************************************************************************/

#ifndef COPYRIGHT_STMT
#define COPYRIGHT_STMT
const char * Copyright = "** Licensed Materials - Property of IBM\n** IBM SPSS Products: Statistics Common \
			** (C) Copyright IBM Corp. 1989, 2022.\n**US Government Users Restricted Rights - Use, duplication or \
			disclosure restricted by GSA ADP Schedule Contract with IBM Corp.";
#endif